/*
 * Help Editor Prototypes
 */
DECLARE_OLC_FUN( hedit_delet		);
DECLARE_OLC_FUN( hedit_delete		);
DECLARE_OLC_FUN( hedit_show		);
DECLARE_OLC_FUN( hedit_name		);
DECLARE_OLC_FUN( hedit_level		);
DECLARE_OLC_FUN( hedit_desc		);
