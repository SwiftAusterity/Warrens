
/* Dave was here */
#define AT_BLACK	    0
#define AT_BLOOD	    1
#define AT_DGREEN           2
#define AT_ORANGE	    3
#define AT_DBLUE	    4
#define AT_PURPLE	    5
#define AT_CYAN	  	    6
#define AT_GREY		    7
#define AT_DGREY	    8
#define AT_RED		    9
#define AT_GREEN	   10
#define AT_YELLOW	   11
#define AT_BLUE		   12
#define AT_PINK		   13
#define AT_LBLUE	   14
#define AT_WHITE	   15
#define AT_BLINK	   16

/* ^^ Ansi junk */


#define C_TESTCOLOR1	  (AT_PINK)
#define C_TESTCOLOR2      (AT_PURPLE + AT_BLINK)
#define C_DEFAULT         (AT_GREY)
